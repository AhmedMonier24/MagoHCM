<?php 
	define('EMAIL', 'info@a1softech.com');
	define('PASS', '123456');
 ?>